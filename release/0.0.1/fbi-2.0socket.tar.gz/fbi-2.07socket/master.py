import subprocess
import os
import sys

print os.getcwd()
os.chdir("/home/pi/fbi/fbi-2.07")

proc = subprocess.Popen(["/home/pi/fbi/fbi-2.07/fbi", "-vt", "1", "-noverbose", "-1", "mijn/blank.png"], stdin=subprocess.PIPE, stdout=sys.stdout)

grep_stdout = proc.communicate(input='+\n')[0]
#time.sleep(5)         
#state = "run"
#while state == "run":
	#input = "lraw_input("Message to FBI>> ")

	#proc.stdin.write(input)
#	grep_stdout = proc.communicate(input='one\n')[0]
#	if input == "l":
#		state = "terminate" # any string other than "run"
		
	#proc.stdin.write(input + "\n")
	#print proc.stdout.readline().rstrip("\n")
