void sane_menu(Widget menu);
