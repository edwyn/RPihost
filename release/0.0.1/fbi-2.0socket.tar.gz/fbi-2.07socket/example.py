#!/usr/bin/python
import time
import subprocess
from BaseHTTPServer import BaseHTTPRequestHandler,HTTPServer

PORT_NUMBER = 8088
#p = subprocess.Popen(['/root/python/mains'], stdin=subprocess.PIPE)
#proc = subprocess.Popen(["/home/pi/fbi/fbi-2.07/fbi", "-vt", "1", "-noverbose", "-1", "mijn/blank.png"], stdin=subprocess.PIPE)
firstCall = False
network_data = 'q'
LAST_RESORT = "http://google.com/"

#This class will handles any incoming request from
#the browser 
class myHandler(BaseHTTPRequestHandler):
	#firstCall = False
        #network_data = 'data from the network goes here'
	
	#Handler for the GET requests
	def do_GET(self):
		global firstCall
                global proc
		self.send_response(200)
		self.send_header('Content-type','text/html')
		self.end_headers()
		# Send the html message
		#if firstCall == True:
		#proc.stdin.write('q')
		#grep_stdout = proc.communicate(input='q\n')[0]
		if firstCall == False:
			self.wfile.write("Hello World false !")
			firstCall = True
		else:
			self.wfile.write("Hello World! "+ LAST_RESORT)
		return

try:
	#Create a web server and define the handler to manage the
	#incoming request

	proc = subprocess.Popen(["/home/pi/fbi/fbi-2.07/fbi", "-vt", "1", "-noverbose", "-1", "mijn/blank.png"], stdin=subprocess.PIPE)
	time.sleep(10)
	proc.communicate(input='q\n')[0]
        #proc.stdin.write('q\n')
	server = HTTPServer(('', PORT_NUMBER), myHandler)
	print 'Started httpserver on port ' , PORT_NUMBER
	
	#Wait forever for incoming htto requests
	server.serve_forever()

except KeyboardInterrupt:
	print '^C received, shutting down the web server'
	server.socket.close()

