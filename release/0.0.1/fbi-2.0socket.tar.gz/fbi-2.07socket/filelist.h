void filelist_window(void);
void filelist_ac(Widget widget, XEvent *event,
		 String *params, Cardinal *num_params);
