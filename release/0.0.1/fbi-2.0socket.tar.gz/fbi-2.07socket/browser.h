void browser_window(char *dirname);
void browser_ac(Widget widget, XEvent *event,
		String *params, Cardinal *num_params);
