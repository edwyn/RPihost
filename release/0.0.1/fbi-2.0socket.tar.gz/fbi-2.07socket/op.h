extern struct ida_op desc_flip_vert;
extern struct ida_op desc_flip_horz;
extern struct ida_op desc_rotate_cw;
extern struct ida_op desc_rotate_ccw;
extern struct ida_op desc_invert;
extern struct ida_op desc_crop;
extern struct ida_op desc_autocrop;
